//
//  ASIWebPageRequestTests.h
//  Mac
//
//  Created by Ben Copsey on 06/01/2011.
//  Copyright 2011 All-Seeing Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASITestCase.h"

@interface ASIWebPageRequestTests : ASITestCase {

}

@end
